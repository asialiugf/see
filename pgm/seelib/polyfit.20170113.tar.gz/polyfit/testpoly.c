#include <stdio.h>
#include <sys/time.h>
#include "polyfit.h"


int main()
{

    struct timeval start, end;
    int cha2;
    int cha1;
    int i = 0 ;
    double slope ;

    //const unsigned int order = 3;
    const unsigned int countOfElements = 6;
    int result;

    // These inputs should result in the following approximate coefficients:
    //         0.5           2.5           1.0        3.0
    //    y = (0.5 * x^3) + (2.5 * x^2) + (1.0 * x) + 3.0

    double xData[6] = {0.0, 1.0, 2.0, 3.0, 4.0, 5.0};
    //double yData[6] = {0.0, 0.8, 0.9, 0.1, -0.8, -1.0};
    //double yData[6] = {0.0, 1.0, 2.0, 3.0, 4.0, 5.0};
    double yData[6] = {0.0, 2.0, 4.0, 6.0, 8.0, 7.0};


    double coefficients[10]; // resulting array of coefs

    // Perform the polyfit

    gettimeofday( &start, NULL );
    for ( i=0;i<10000;i++ )
    {
        result = polyfit(xData,
                     yData,
                     countOfElements,
                     2,
                     &slope,
                     coefficients) ;
    }
   gettimeofday( &end, NULL ); 

    printf( "%10f %10f %10f slope:%10f \n",coefficients[2],coefficients[1],coefficients[0],slope) ;

    result = polyfit(xData,
                     yData,
                     countOfElements,
                     3,
                     &slope,
                     coefficients);

    printf( "%10f %10f %10f %10f slope:%10f \n",coefficients[3],coefficients[2],coefficients[1],coefficients[0],slope) ;

    result = polyfit(xData,
                     yData,
                     countOfElements,
                     4,
                     &slope,
                     coefficients);

    printf( "%10f %10f %10f %10f %10f slope:%10f \n",coefficients[4],coefficients[3],coefficients[2],coefficients[1], coefficients[0],slope) ;


    result = polyfit(xData,
                     yData,
                     countOfElements,
                     1,
                     &slope,
                     coefficients);
    printf( " %10f %10f slope:%10f \n",coefficients[1],coefficients[0],slope) ;

    cha2 = end.tv_usec-start.tv_usec ;
    cha1 = end.tv_sec-start.tv_sec ;
    printf( "sec:%d usec:%d\n",cha1,cha2 );

    return result ;
}
